-- -------------------------------------------------------------
-- TablePlus 4.6.8(424)
--
-- https://tableplus.com/
--
-- Database: tfmaker
-- Generation Time: 2022-10-06 11:12:36.9490
-- -------------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` char(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_tfmaker_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_tfmaker_user_id` FOREIGN KEY (`user_id`) REFERENCES `tfmaker_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `tfmaker_service`;
CREATE TABLE `tfmaker_service` (
  `id` char(32) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `type` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `url` varchar(200) NOT NULL,
  `extra` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `tf_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tf_key` (`tf_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `tfmaker_user`;
CREATE TABLE `tfmaker_user` (
  `is_superuser` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `password` varchar(128) NOT NULL,
  `id` char(32) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `tfmaker_user_groups`;
CREATE TABLE `tfmaker_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` char(32) NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfmaker_user_groups_user_id_group_id_c396888a_uniq` (`user_id`,`group_id`),
  KEY `tfmaker_user_groups_group_id_93c24ab1_fk_auth_group_id` (`group_id`),
  CONSTRAINT `tfmaker_user_groups_group_id_93c24ab1_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `tfmaker_user_groups_user_id_fce055d6_fk_tfmaker_user_id` FOREIGN KEY (`user_id`) REFERENCES `tfmaker_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `tfmaker_user_user_permissions`;
CREATE TABLE `tfmaker_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` char(32) NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfmaker_user_user_permis_user_id_permission_id_32435dd4_uniq` (`user_id`,`permission_id`),
  KEY `tfmaker_user_user_pe_permission_id_6a2bad68_fk_auth_perm` (`permission_id`),
  CONSTRAINT `tfmaker_user_user_pe_permission_id_6a2bad68_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `tfmaker_user_user_pe_user_id_5de5134e_fk_tfmaker_u` FOREIGN KEY (`user_id`) REFERENCES `tfmaker_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add content type', 4, 'add_contenttype'),
(14, 'Can change content type', 4, 'change_contenttype'),
(15, 'Can delete content type', 4, 'delete_contenttype'),
(16, 'Can view content type', 4, 'view_contenttype'),
(17, 'Can add session', 5, 'add_session'),
(18, 'Can change session', 5, 'change_session'),
(19, 'Can delete session', 5, 'delete_session'),
(20, 'Can view session', 5, 'view_session'),
(21, 'Can add user', 6, 'add_user'),
(22, 'Can change user', 6, 'change_user'),
(23, 'Can delete user', 6, 'delete_user'),
(24, 'Can view user', 6, 'view_user'),
(25, 'Can add service', 7, 'add_service'),
(26, 'Can change service', 7, 'change_service'),
(27, 'Can delete service', 7, 'delete_service'),
(28, 'Can view service', 7, 'view_service');

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2022-09-04 23:46:07.839224', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'worker-main', 1, '[{\"added\": {}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(2, '2022-09-04 23:46:30.157450', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'S3', 2, '[{\"changed\": {\"fields\": [\"Name\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(3, '2022-09-04 23:46:40.365601', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'S3', 2, '[{\"changed\": {\"fields\": [\"Type\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(4, '2022-09-04 23:57:26.586350', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'S3', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(5, '2022-10-05 15:11:24.205937', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Type\", \"Name\", \"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(6, '2022-10-05 15:16:11.884526', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(7, '2022-10-05 15:18:42.672167', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Description\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(8, '2022-10-05 15:32:31.306774', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Description\", \"Url\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(9, '2022-10-05 15:41:30.022674', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Url\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(10, '2022-10-05 15:48:23.045234', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Description\", \"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(11, '2022-10-05 15:51:15.570266', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(12, '2022-10-05 15:51:20.135153', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(13, '2022-10-05 15:51:54.231770', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(14, '2022-10-05 15:52:05.510823', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(15, '2022-10-05 15:53:38.906376', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(16, '2022-10-05 15:59:32.466940', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(17, '2022-10-05 16:01:01.283153', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(18, '2022-10-05 16:04:03.133423', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(19, '2022-10-05 16:16:21.784114', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[{\"changed\": {\"fields\": [\"Tf key\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(20, '2022-10-05 16:19:27.966863', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'EC2', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(21, '2022-10-05 16:50:54.868600', '3e7ebad0-93ce-41d3-b51f-796f86907406', 'Elastic Load Balancing', 1, '[{\"added\": {}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(22, '2022-10-05 16:54:46.226608', '3e7ebad0-93ce-41d3-b51f-796f86907406', 'Elastic Load Balancing', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(23, '2022-10-05 16:59:08.694812', '3e7ebad0-93ce-41d3-b51f-796f86907406', 'Elastic Load Balancing', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(24, '2022-10-05 17:05:06.493807', '0aea910b-42ff-4356-a2f5-6f7a7ece2224', 'Amason EC2', 2, '[{\"changed\": {\"fields\": [\"Name\", \"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(25, '2022-10-05 17:05:12.839996', '3e7ebad0-93ce-41d3-b51f-796f86907406', 'Elastic Load Balancing', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(26, '2022-10-05 17:25:32.904142', '3e7ebad0-93ce-41d3-b51f-796f86907406', 'Elastic Load Balancing', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(27, '2022-10-05 18:27:34.050508', '42e64b23-e52f-433a-8b40-86652bba2775', 'Pub/Sub', 1, '[{\"added\": {}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(28, '2022-10-05 18:28:15.550572', '42e64b23-e52f-433a-8b40-86652bba2775', 'Pub/Sub', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(29, '2022-10-05 18:33:36.237951', '42e64b23-e52f-433a-8b40-86652bba2775', 'Pub/Sub', 2, '[]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(30, '2022-10-05 20:40:43.579597', '3e7ebad0-93ce-41d3-b51f-796f86907406', 'Elastic Load Balancing', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce'),
(31, '2022-10-05 20:45:59.867268', '3e7ebad0-93ce-41d3-b51f-796f86907406', 'Elastic Load Balancing', 2, '[{\"changed\": {\"fields\": [\"Extra\"]}}]', 7, '338bb0563aa2485eba4b67311024f6ce');

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(2, 'auth', 'permission'),
(3, 'auth', 'group'),
(4, 'contenttypes', 'contenttype'),
(5, 'sessions', 'session'),
(6, 'account', 'user'),
(7, 'api', 'service');

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2022-09-04 23:39:39.182922'),
(2, 'contenttypes', '0002_remove_content_type_name', '2022-09-04 23:39:40.207938'),
(3, 'auth', '0001_initial', '2022-09-04 23:39:42.564118'),
(4, 'auth', '0002_alter_permission_name_max_length', '2022-09-04 23:39:42.970581'),
(5, 'auth', '0003_alter_user_email_max_length', '2022-09-04 23:39:43.018780'),
(6, 'auth', '0004_alter_user_username_opts', '2022-09-04 23:39:43.054285'),
(7, 'auth', '0005_alter_user_last_login_null', '2022-09-04 23:39:43.100425'),
(8, 'auth', '0006_require_contenttypes_0002', '2022-09-04 23:39:43.130550'),
(9, 'auth', '0007_alter_validators_add_error_messages', '2022-09-04 23:39:43.162383'),
(10, 'auth', '0008_alter_user_username_max_length', '2022-09-04 23:39:43.199393'),
(11, 'auth', '0009_alter_user_last_name_max_length', '2022-09-04 23:39:43.244916'),
(12, 'auth', '0010_alter_group_name_max_length', '2022-09-04 23:39:43.359687'),
(13, 'auth', '0011_update_proxy_permissions', '2022-09-04 23:39:43.416619'),
(14, 'auth', '0012_alter_user_first_name_max_length', '2022-09-04 23:39:43.586869'),
(15, 'account', '0001_initial', '2022-09-04 23:39:47.068697'),
(16, 'admin', '0001_initial', '2022-09-04 23:39:48.266015'),
(17, 'admin', '0002_logentry_remove_auto_add', '2022-09-04 23:39:48.307883'),
(18, 'admin', '0003_logentry_add_action_flag_choices', '2022-09-04 23:39:48.353548'),
(19, 'api', '0001_initial', '2022-09-04 23:39:48.539699'),
(20, 'sessions', '0001_initial', '2022-09-04 23:39:49.030475'),
(21, 'api', '0002_service_tf_key_alter_service_extra', '2022-10-05 16:15:03.887078');

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('i28x1fznxq3ws6bw926j55z1wdiqk720', '.eJxVzDkOwjAQheG7uCaWl_FGSc8Zohl7hrAokbJUiLujSCmgfv_33qrHbR36beG5vzd1Vt5nIhNi5xFdBzlwRwjUxeStNQ4kVlanX0ZYnzzutj1wvE26TuM630nviT7WRV-nxq_L0f4dDLgMu2ZfUhEuroGt0UINlXPwQNFA9LaF7FCSEEhpqdgoKFyBJDcswRv1-QLMAUFR:1og57y:XiunKdZHVpbgNWweGRJAOyjP0iewqRY6HgDLNWhKOZY', '2022-10-19 14:12:02.234700'),
('kpctn49u7uy8524doj4ooreb3kj044y8', '.eJxVzDkOwjAQheG7uCaWl_FGSc8Zohl7hrAokbJUiLujSCmgfv_33qrHbR36beG5vzd1Vt5nIhNi5xFdBzlwRwjUxeStNQ4kVlanX0ZYnzzutj1wvE26TuM630nviT7WRV-nxq_L0f4dDLgMu2ZfUhEuroGt0UINlXPwQNFA9LaF7FCSEEhpqdgoKFyBJDcswRv1-QLMAUFR:1og5s8:rSi_mO05O69UUbxWYYkUdTZQuxLq9KrfmXWNX-2yOyk', '2022-10-19 14:59:44.109326'),
('xan5mou9iypp7nf6rsynnvnvdu5ramcn', '.eJxVzDkOwjAQheG7uCaWl_FGSc8Zohl7hrAokbJUiLujSCmgfv_33qrHbR36beG5vzd1Vt5nIhNi5xFdBzlwRwjUxeStNQ4kVlanX0ZYnzzutj1wvE26TuM630nviT7WRV-nxq_L0f4dDLgMu2ZfUhEuroGt0UINlXPwQNFA9LaF7FCSEEhpqdgoKFyBJDcswRv1-QLMAUFR:1oUzEK:JX1FNdf2RilCrCUcXkKTHvYiHFfwv6cYaJa3O_ulaSg', '2022-09-18 23:40:44.626252');

INSERT INTO `tfmaker_service` (`id`, `provider`, `type`, `name`, `description`, `url`, `extra`, `created_at`, `tf_key`) VALUES
('0aea910b42ff4356a2f56f7a7ece2224', 'aws', 'compute', 'Amason EC2', 'Amazon Elastic Compute Cloud (Amazon EC2) offers the broadest and deepest compute platform, with over 500 instances and choice of the latest processor, storage, networking, operating system, and purchase model to help you best match the needs of your workload. We are the first major cloud provider that supports Intel, AMD, and Arm processors, the only cloud with on-demand EC2 Mac instances, and the only cloud with 400 Gbps Ethernet networking. We offer the best price performance for machine learning training, as well as the lowest cost per inference instances in the cloud. More SAP, high performance computing (HPC), ML, and Windows workloads run on AWS than any other cloud.', 'https://aws.amazon.com/ec2/', '[{\"max\": \"\", \"min\": \"\", \"name\": \"ami\", \"type\": \"string\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"instance_type\", \"type\": \"string\", \"choices\": [\"t2.micro\"], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"ports\", \"type\": \"array\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"1\", \"name\": \"count\", \"type\": \"integer\", \"choices\": [], \"default\": \"1\", \"is_required\": false, \"is_multiple_choice\": false}]', '2022-09-04 23:46:07.817270', 'ec2'),
('3e7ebad093ce41d3b51f796f86907406', 'aws', 'compute', 'Elastic Load Balancing', 'Elastic Load Balancing (ELB) automatically distributes incoming application traffic across multiple targets and virtual appliances in one or more Availability Zones (AZs).', 'https://aws.amazon.com/elasticloadbalancing/', '[{\"max\": \"\", \"min\": \"\", \"name\": \"availability_zones\", \"type\": \"array\", \"choices\": [\"eu-west-2a\"], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": true}, {\"max\": \"\", \"min\": \"\", \"name\": \"name-elb\", \"type\": \"string\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"instances\", \"type\": \"string\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"cross_zone_load_balancing\", \"type\": \"boolean\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"idle_timeout\", \"type\": \"integer\", \"choices\": [], \"default\": \"400\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"connection_draining\", \"type\": \"boolean\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"connection_draining_timeout\", \"type\": \"integer\", \"choices\": [], \"default\": \"400\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"listeners.instance_port\", \"type\": \"integer\", \"choices\": [], \"default\": \"8080\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"listeners.instance_protocol\", \"type\": \"string\", \"choices\": [], \"default\": \"HTTP\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"listeners.lb_port\", \"type\": \"integer\", \"choices\": [], \"default\": \"80\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"listeners.lb_protocol\", \"type\": \"string\", \"choices\": [], \"default\": \"HTTP\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"healthCheck.healthy_threshold\", \"type\": \"integer\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"healthCheck.unhealthy_threshold\", \"type\": \"integer\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"healthCheck.timeout\", \"type\": \"integer\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"healthCheck.target\", \"type\": \"string\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}, {\"max\": \"\", \"min\": \"\", \"name\": \"healthCheck.interval\", \"type\": \"integer\", \"choices\": [], \"default\": \"\", \"is_required\": false, \"is_multiple_choice\": false}]', '2022-10-05 16:50:54.858919', 'elb'),
('42e64b23e52f433a8b4086652bba2775', 'gcp', 'storage', 'Pub/Sub', 'Pub/Sub allows services to communicate asynchronously, with latencies on the order of 100 milliseconds.', 'https://cloud.google.com/pubsub', '[{\"max\": \"\", \"min\": \"\", \"name\": \"topic\", \"type\": \"string\", \"choices\": [], \"default\": \"\", \"is_required\": true, \"is_multiple_choice\": false}]', '2022-10-05 18:27:34.039102', 'pubsub');

INSERT INTO `tfmaker_user` (`is_superuser`, `is_staff`, `is_active`, `password`, `id`, `last_name`, `first_name`, `email`, `last_login`, `created_at`) VALUES
(1, 1, 1, 'pbkdf2_sha256$320000$qbp6iiPzpydDqUXdrKxiDJ$IJqKrQuDHKlQdTkVjiUp/RHcaEoWl5imj9JalbUR9nI=', '338bb0563aa2485eba4b67311024f6ce', NULL, NULL, 'mail@adebayo.fr', '2022-10-05 14:59:44.088946', '2022-09-04 23:40:29.582413');



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;